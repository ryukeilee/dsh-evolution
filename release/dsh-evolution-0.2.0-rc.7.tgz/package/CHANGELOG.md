# Changelog

Versions here are development artifacts of the standalone `dsh-evolution`
bundle. They are not npm releases. The supported DSH versions are exact
alternatives in `peerDependencies`, and a version is only added there after it
passes the full install/boot/upgrade acceptance: read the entry for the version
you install before upgrading DSH.

## 0.2.0-rc.7 — failure memory integrity

- 修复 file 后端失败记忆的损坏输入路径：`entries` 中出现非对象记录、或记录嵌套超过加载边界（64 层；`snapshot()` 克隆在这之前会因过深而栈溢出）时，插件不再在启动时崩溃，而是像解析失败 / 结构失效一样隔离原文件、以空 memory 继续并留下可查询 warning；doctor 与运行时使用同一个判定函数，不再出现“运行时拒绝、doctor 报 ok”。
- 从旧数据恢复、缺少 `signature` 的记录改为按整条内容派生身份（深度受限的稳定序列化）：不同记录不再因缺失键被静默合并（`compact()` 曾把合并结果写回磁盘），完全相同的记录仍会去重。
- 显式 `signature` 只接受非空字符串；其它值改按 `signature()` 计算，避免 `record()` 的保留键与实际存储键不一致。
- `record()` 的保留不再可能裁掉本次写入：时钟回拨或异常 `lastSeenAt` 使新记录排在满仓之后时，淘汰最旧记录而不是丢掉刚观察到的失败，返回值不再因自身的裁剪而缺失。
- 加载时拒绝 JSON 无法保真表示的值（±Infinity/NaN、-0）并按损坏状态隔离原文件；写入路径把非有限数规范化为字符串、-0 规范化为 0，避免插件自己写出下次启动会被拒绝或与其它记录共享身份的记录。
- 加载时检测 JSON 数字字面量的精度丢失（如 `9007199254740993`、`1.0000000000000001`、`1e-400`）：`JSON.parse` 之后原文差异已不可观察，因此对原文做精确十进制比较，命中即按损坏状态隔离原文件，doctor 同步报 `degraded`。
- 写入路径把 `undefined` 数组元素/空洞与 `undefined` 属性规范化为落盘后的形状（`null` / 删除），使身份在写入、重载、再写入之间保持一致。
- 解析前检查对象的重复键（含转义解码后的键名）：重复键在 `JSON.parse` 中后者覆盖前者，不同原文会得到相同记录；命中即隔离原文件。
- 严格 UTF-8 解码内存文件：非法字节不再被替换字符“修复”而与其它记录合并，命中即隔离并保留原字节。
- `compactValue` 改用 `Object.fromEntries` 写回对象属性，`__proto__` 自有属性不再被原型 setter 吞掉。
- 保持 BOM 文件的既有语义：UTF-8 BOM 不属于 JSON，严格解码保留它以便解析失败并按损坏状态隔离，运行时与 doctor 一致，不再出现“运行时接受、doctor 报 degraded、保存时静默去掉 BOM”的分歧。
- 保留 schema 1 格式、`record()` 的重复语义（`count` 递增、`firstSeenAt` 与模式身份不变）、`tmp`+`rename` 原子写入与隔离恢复语义。
- 本候选仅在本地固定与验收，未创建 tag 或进行外部发布。卸载/重装后 memory 文件哈希变化的调查结论（属预期的 `count`/`lastSeenAt` 更新，非持久化缺陷）见 `docs/evidence/memory-hash-investigation.md`。

## 0.2.0-rc.6 — redundant work removal

- 删除同一调用路径中重复执行的工作：语义 GC 不再为每条可退休记录线性扫描整张 canonical 表；失败记忆 `record()` 与加载不再为丢弃的返回值深拷贝整份记录；observation 过滤不再逐条规范化同一查询词；strategy 与 capability 快照不再为取计数重复生成整份列表。
- 保留持久化格式、认证、fsync、事务、恢复、回滚与跨进程锁语义，官方 DSH 零源码 patch；历史 tag 和发布附件不变。
- 事件同步路径的两项候选优化经三轮独立对抗式审查后**整体撤回**，生产代码恢复基线行为：标记表摘要复用被“端口存活期间经官方句柄回退标记”和“同一对象原地修改后写入失败”两处反例击穿；恢复安装的“只校验使用到的字段”被“被拒绝的提交已把暂存文件装进实时归档树”击穿。两项都在真实官方 JSON 后端复现，稳态与带新事件的 `flush()` 因此都没有收益。
- 可复现前后对比（3 轮交替、中位数）：canonical 3000 时语义 GC 94.475 → 67.519 ms（−28.53%）；`record()` 重复条目 1.1321 → 0.7594 ms（−32.92%）；带查询词的 observation 列表 1.3183 → 0.5106 ms（−61.27%）；`strategy.snapshot()` 3.0507 → 1.5348 ms（−49.69%）；`capability.snapshot()` 0.8837 → 0.4866 ms（−44.94%）。收益边界、撤回记录、反例与原始数据见 `docs/performance/redundant-work.md`。

## 0.2.0-rc.5 — reliability fixes

- 保留 proposal 快照，在 Trial 首次运行时修改前同步捕获恢复基线；正常 propose→trial 宿主加载不再误报恢复失败。基线不在后续 inspect、measure 或清理时重建，Trial 期间真实并发漂移仍拒绝恢复并保留目标锁。
- 服务清单读取异常标记为不可用，拒绝以两份空清单证明恢复；普通 service lookup 的容错行为与正常未绑定声明保持兼容。
- 保留 stop/undefine 回执、安全守卫、二次确认、Promotion、Canary、恢复和回滚语义；官方 DSH 零源码 patch，历史 tag 和发布附件不变。
- 七项边界回归及真实双宿主探针覆盖本次修复；发布链继续要求 Node 22/24、完整测试、固定产物、来源追溯、远端 CI、CodeQL 和发布后验收。结果与剩余风险见 `docs/evidence/rc5-release-audit.json` 与 `docs/core-reliability.md`。

## 0.2.0-rc.4 — final local performance candidate

- 收敛领域查询元数据投影、运行时检查投影、签名排序键复用、冷历史诊断、事件桥证据分块恢复五轮优化，保留全部历史基准、失败记录和差分回归。
- 统一源码、固定 tarball、校验和、manifest 与两个官方宿主的完整验收证据；未降低发布验证要求。
- 本候选仅在本地固定，未创建 tag 或进行外部发布。可复现结果与收益边界见 `docs/performance/final-candidate.md`。

## 0.2.0-rc.3 — performance candidate

- 官方领域查询保留完整历史读取、去重和计数，仅深拷贝最多 50 条返回记录；
  三轮同负载 CPU 减少 30–49%，数据和收益边界见 `docs/performance/domain-query.md`。

- 在每个 agent step / 工具结束的事件同步中，移除重复 JSON 解析，并仅为
  未提交事件构造 DTO；全部历史记录仍逐条验证 MAC、writer 和同 ID 冲突。
- 可复现多规模数据与适用范围见 `docs/performance/domain-replay.md`。
- Reuse archive directory lookups within one index load on the official domain
  observation path; retain fresh discovery on every subsequent load.
- Preserve archive reconciliation, checksums, MAC verification, fsync and
  pending/final transaction semantics; no official DSH source changes.
- On the reproducible 256-segment workload: median observation latency -42.61%,
  process CPU time -79.62%, directory enumeration calls -92.49%.
- 历史发布及发布后双宿主验收记录见 `docs/evidence/rc3-release-audit.json`；本轮不修改历史 tag 或公开资产。

## 0.2.0-rc.2 — release candidate

Supported hosts: DSH `0.2.0-rc.2` and `0.2.1-alpha.1` (exact alternatives),
Node `^22.19.0 || >=24.0.0`. Not published to npm.

本候选修复两条 CodeQL high：shell 守卫的多项式回溯，以及指标投影的弱随机兜底 ID。保持核心 Evolution 流程与显式指标身份，重新执行双宿主真实验收。发布链验证 sourceCommit 的实际包内容，确保 tag、源 commit、manifest 与产物内容一致。

### Added

- **A source-commit pin.** `npm run release:publish` now records `sourceCommit`
in `release/manifest.json`, and the release workflow requires it: a new release
cannot be published unless the pin names a commit in the tagged history. The
check is `scripts/release/verify-provenance.mjs`, covered by
`test/release-provenance.test.mjs`.
- **Code scanning.** `.github/workflows/codeql.yml` runs CodeQL for
`javascript-typescript` on `main`, on every pull request and weekly, and uploads
the SARIF results to GitHub code scanning.

### Changed

- **The release workflow can no longer overwrite a published asset.** It refuses
to touch a release that is already published or already has assets, uploads
without `--clobber`, and downloads the assets GitHub ends up serving to re-verify
them against the pin. `workflow_dispatch` gained a `dry_run` input that runs
every check and touches nothing.
- **The release workflow verifies tag, commit, manifest and checksums before
attaching anything.** It checks out full history (so the pinned source commit
can be walked) and fails when the tag does not match the version, the checked-out
commit, the pinned source commit or the pinned content.
- **GitHub Actions now run on Node 24.** `actions/checkout` and
`actions/setup-node` move to `v7`, `actions/upload-artifact` to `v7` and
`pnpm/action-setup` to `v6`, which removes the `Node.js 20 is deprecated`
runner warning the previous releases emitted.
- **`test/workflows.test.mjs`** now locks the release guarantees, the CodeQL job
and the action runtimes instead of only the job names.

### Notes

- `lib/guard.js` 使有序命令/写动词在互不重叠的候选区间内匹配，保留导出的 `RegExp` 接口并消除无界回溯，重定向去掉可重试的数字/空白前缀；保留 deny/allow 决策并增加带子进程硬期限的风险回归。
- 指标兜底身份使用 `crypto.randomUUID()`，同一投影的 `id` 与对应 `taskId` / `goalId` / `agentId` / `sessionId` 一致；调用方身份优先级不变。
- `sourceCommit` 必须来自已提交的包内容，且其 git 对象摘要等于 tag 树与 tarball，祖先关系不再是唯一来源校验。
- 原同名 rc.2 draft/tag 经维护者授权重建；旧记录保留，历史 rc.1 tag 和资产不变。
- The `v0.2.0-rc.1` tag points at a commit whose committed artifact differs from
the bytes that were published under that release. The hardened workflow now
fails on exactly that mismatch. It is recorded in `RELEASE.md` as a known risk of
the historical release; rewriting the tag or the release is out of scope.

## 0.2.0-rc.1 — release candidate

Supported hosts: DSH `0.2.0-rc.2` and `0.2.1-alpha.1` (exact alternatives),
Node `^22.19.0 || >=24.0.0`. Not published to npm.

This candidate contains **no runtime change**: the shipped `lib/` is exactly
`0.2.0-dev.6`, re-verified end to end on both hosts. It adds the release and
verification layer that turns that state into a reviewable artifact.

### Added

- **A release pin: `release/manifest.json` + the released tarball.** The bytes
  that get published are committed and verified rather than rebuilt. Packing is
  only byte-stable within one npm version (see *Fixed*), so one artifact is
  stored: `npm run release:publish` copies the build into `release/`, records
  its `sha256` and its environment-independent `contentSha256`, and
  `npm run release:verify [<tarball>]` checks either one. `--content-only`
  checks a locally rebuilt tarball, whose bytes may legitimately differ.
- **`npm run pack:check`** replaces the bare `npm pack --dry-run`: it fails on
  a pack that is not byte-stable in this environment, on an archive that is not
  exactly `package.json#files`, on a non-canonical file mode, on shipped text
  carrying a local home path or credential-shaped material, on
  `package-lock.json`/`package.json` drift, on a version that is not a
  pre-release, on a README that documents a superseded version, on a missing
  CHANGELOG entry, on missing install/doctor/upgrade/rollback/uninstall
  instructions — and on a `release/`, `docs/evidence/` or working tree that no
  longer describes the pinned artifact.
- **A content digest instead of a byte-only guarantee.** The archive is read
  with Node's `zlib` and a minimal ustar reader (no external `tar`), and
  `contentSha256` covers every entry's path, mode and content. This is what the
  acceptance evidence, the pin and the CI check across platforms.
- **A committed host-acceptance harness**
  (`scripts/acceptance/run-host-acceptance.mjs`). It installs the requested
  official DSH release into a throwaway runtime, installs the packed tarball
  through the official plugin CLI into a fresh `$DSH_HOME`, and drives the real
  host through the CLI doctor, the core
  `inspect→propose→trial→measure→revert` flow (requiring proven runtime
  recovery), the official pluginManager disable/enable semantics, CLI
  uninstall/reinstall with data retention, the README upgrade and rollback
  flows (a re-versioned build of the same tree, then the current tarball), real
  promotion with a second confirmation gate, startup-canary commit across a
  restart, and a canary rollback that removes only the new candidate. Its
  evidence records both the bytes it installed and the content digest, with
  local scratch paths redacted.
- **Committed acceptance evidence** for both supported hosts:
  `docs/evidence/dsh-0.2.0-rc.2.json` and
  `docs/evidence/dsh-0.2.1-alpha.1.json`.
- **GitHub CI** (`.github/workflows/ci.yml`): unit tests on Node `22.19.0` and
  `24.x`, a packaging job (byte stability, allow-list, canonical modes, the
  committed pin, a `--content-only` check of a locally rebuilt artifact, and a
  doctor start with no host packages present), and a per-host acceptance job
  that also asserts its evidence matches the pinned content.
  `test/workflows.test.mjs` parses both workflow files, pins the CI job set and
  the accepted host matrix to the declaration, and fails if the release
  workflow could publish anything other than a draft, rebuild the released
  bytes, or reach npm. `test/release-pin.test.mjs` checks the pin against the
  committed artifact and the working tree without running `npm pack`.
- **Tag-triggered release workflow** (`.github/workflows/release.yml`) that
  verifies the tag against the version, verifies the pinned artifact, and
  attaches exactly those bytes to a **draft** GitHub release. It deliberately
  does not rebuild: a rebuild on the runner would have different bytes from the
  artifact the acceptance ran against.
- **`RELEASE.md`** with the artifact list, the reproduction steps, what
  "reproducible" does and does not mean here, and the remaining release risks.

### Fixed

- **`npm test` did not run on Node 22 or 24.** `node --test test/` treats the
  argument as a module path on those versions and failed with
  `Cannot find module '.../test'`, so CI could never go green on the declared
  engine range. The suite now uses explicit globs
  (`node --test "test/**/*.test.mjs" "test/**/*.test.js"`), verified on Node
  `22.19.0` and `26.10.0`. As a side effect of the same fix,
  `test/full-cross-session.integration.mjs` — a real integration test that the
  old command silently never ran — is now discovered and passes (renamed to
  `*.integration.test.mjs`).
- **The tarball used to depend on the checkout's umask.** `npm pack` records the
  on-disk mode, so three files that happened to be `0600` in the development
  tree produced a different hash than the same commit in a fresh `git clone`
  (`0644`), while git tracked no such difference. Packaging now copies exactly
  the declared entries into a staging directory and normalises modes to
  `0644`/`0755`.
- **The "reproducible tarball" claim was wrong across npm versions.** The same
  tree packs to different bytes under npm 10 and npm 11 — the compression runs
  through the bundled zlib. Measured: `46f6e4a4…` with npm `10.9.3`, `040e0d9e…`
  with npm `11.19.1`, with byte-identical unpacked files and identical
  uncompressed tar size. The guarantee is now split honestly: byte identity
  within one environment, `contentSha256` everywhere, and one pinned artifact
  for what is actually published.
- **`lib/`-only runtime files no longer ship the release tooling.**
  `package.json#files` now names `scripts/doctor.mjs` and
  `scripts/import-evolution-data.mjs` instead of the whole `scripts/`
  directory, so the acceptance harness and release scripts stay out of the
  user-facing bundle (48 entries instead of 56).

### Notes

- The doctor still reports `degraded` immediately after a fresh install
  (`data.root` is created on first run); the post-boot diagnosis is `healthy`.
- Nothing was added to `peerDependencies`: `0.2.1-alpha.1` remains supported
  only because the full acceptance passes on it.

## 0.2.0-dev.6 — superseded by 0.2.0-rc.1

Supported hosts: DSH `0.2.0-rc.2` and `0.2.1-alpha.1` (exact alternatives),
Node `^22.19.0 || >=24.0.0`.

### Changed

- **The service inventory no longer depends on a private Cordis method.**
  `ctx.reflect._getImpl()` is replaced by the documented `ctx.reflect.store`
  ("service implementations, keyed by isolation label", with the exported `Impl`
  type) plus the documented `Context.isolate` key. The private method is kept
  only as a fallback for a host where `reflect.store` is unreachable, and the
  doctor records which path answered (`public: ctx.reflect.store +
  Context.isolate` on both verified hosts). Verified equivalent to
  `_getImpl(name, false)` for bound, unbound, isolated and disposed providers.
- **The promotion gate no longer trusts a numeric `FiberState`.** `FiberState`
  is a `const enum`, so it is erased from the published cordis runtime and
  `state !== 2` was an unverifiable literal. `fiberIsActive()` decides ACTIVE
  from the documented `uid`, `store` and `inertia` fields, asserted equal to
  `state === FiberState.ACTIVE` across every lifecycle transition
  (PENDING/LOADING/ACTIVE/FAILED/DISPOSED/UNLOADING) against the real package.
- **The mounted promoted row is resolved through the loader's public API.**
  `EntryTree.store[rowId]` is replaced by `EntryTree.resolve(rowId)`; the
  verify path awaits the row's fiber (`Fiber.await()`) so an in-flight
  transition is settled before the activity decision, and a failed activation is
  reported as inactive with its own cause.
- **`lib/cordis-compat.js` is the single source of truth for host-surface
  dependencies.** The runtime readers and the doctor consume the same classified
  table (public / undocumented / private, owning package, what is read, the
  public replacement, or the recorded reason why none exists).
- **`host.version` now reports whether the found host is one of the versions
  verified by a real acceptance run** (`verified`, `verifiedHosts`), derived from
  the declared alternatives so the answer cannot drift from the declaration.

### Added

- DSH `0.2.1-alpha.1` is a verified supported host. It was accepted only after
  the full acceptance run passed on it, against a fresh `$DSH_HOME`: install,
  boot, all 9 tool registrations, in-session and CLI doctor, core
  `inspect→propose→trial→measure→revert`, execution-bridge fault injection with
  an idempotent repair, restart recovery, promotion to `canary-observing`, stable
  commit, canary rollback, interrupted-promotion recovery, fail-safe on a
  `rollback-failed` journal, unsupported-host blocking, disable/enable,
  uninstall/reinstall with data retention, and a final doctor.
- `test/cordis-compat.test.mjs`: contract tests against the real installed
  cordis / loader / official Include packages — `serviceImpl` equivalence with
  `_getImpl`, the isolate-symbol identity assertion, `fiberIsActive`
  equivalence across all six lifecycle states, the recorded surface
  classification, a real promoted-Include mount with verify/health, and a torn
  composition failing closed.
- A regression test proving the doctor CLI starts with **no host package
  resolvable** (the bundle is copied without any `node_modules`), so a
  reintroduced host import in the doctor's import graph fails in CI instead of
  only in a real install.
- A regression test asserting no `lib/` file decides a fiber state from a
  numeric literal, and one asserting the declared support matrix equals the
  verified host list.

### Fixed

- **The service-inventory change must not put a host import into the doctor's
  import graph.** A first attempt imported `@deepseek-ai/cordis` inside
  `lib/cordis-compat.js`, which broke the doctor CLI in a real install
  (`ERR_MODULE_NOT_FOUND`) while the plugin itself still booted — the same
  constraint that makes `js-yaml` a bundle dependency. The module now imports
  nothing from the host: it takes the authoritative `Context.isolate` from the
  bundle entry at boot, falls back to the registered
  `Symbol.for('cordis.isolate')` key cordis itself builds, and the regression is
  pinned by a test that starts the doctor with no `node_modules` present.
- **`ctx.registry.values()`, `ctx.reflect.props`, `Fiber.getEffects()` and the
  `Fiber` lifecycle fields were misreported as non-public.** They are documented
  members of the exported cordis classes, so they are now classified as public
  and no longer counted as upgrade risk; only `ctx.events._hooks` and the
  `_getImpl` fallback remain private.

### Notes

- `scripts/import-evolution-data.mjs` is unchanged: staged, SHA256-verified,
  atomic, idempotent imports that refuse to merge differing source content.
- Known non-blocking limits are reported by every diagnostics run
  (`degradedCapabilities`): advisory domain evaluator, `continuous/` and
  `governance/` not wired into the live loop, host-only promotion through a
  cooperative (non-sandbox) gate, disabled legacy adapters, and the recorded
  private/undocumented surfaces listed in `COMPATIBILITY.md`.

## 0.2.0-dev.5 — unreleased

Supported host: DSH `0.2.0-rc.2` (exact), Node `^22.19.0 || >=24.0.0`.

### Added

- **Model-free diagnostics.** `lib/diagnostics.js` plus a
  `dsh-evolution-doctor` command (`scripts/doctor.mjs`, also runnable as
  `node <profile>/node_modules/dsh-evolution/scripts/doctor.mjs`). It reports
  `ok` / `degraded` / `blocked` / `not-evaluated` with per-check evidence over
  the installed package, the resolved DSH host and its module versions, the
  composed profile (official `dsh --dump-config`), live Cordis services, tool
  registration, internal-API probes, the Evolution data root, memory, cold
  archives, the signed execution event bridge, the domain aggregate and its
  archive lock, the legacy-import manifest, and promotion
  journal/composition/pointer. Exit codes: `0` healthy, `1` degraded,
  `2` blocked.
- **In-session diagnostics.** The `evolution_doctor` tool and
  `ctx.evolution.diagnose()` return the same report while checking the live
  registry (9 tools) and the mounted promotion Include adapter.
- **Safe, idempotent repairs** (`--repair`): interrupted promotion-journal
  rollback (backup + CAS), committed-journal cleanup, event-bridge
  partial-tail trimming, orphan domain staging removal, migration staging
  cleanup, and stale archive-lock removal. Every repair re-verifies and is a
  no-op on a second run. `rollback-failed`, unparsable or out-of-boundary
  journals, unverifiable event MACs, conflicting event ids, missing pending
  archives and altered immutable migration evidence stay `blocked` with
  `recoverable=false` and are never modified.
- `CHANGELOG.md` and a `bin` entry so the doctor is discoverable by name.

### Fixed

- **Startup was permanently blocked by an interrupted archive-lock write.** An
  empty or unparsable `domain-archive.lock` used to throw
  `E_DOMAIN_ARCHIVE_LOCK` forever. The runtime now reclaims a lock whose owner
  is dead, and waits for an unparsable lock to settle before reclaiming it, so
  an in-flight writer is never displaced. A lock held by a live process is
  still never stolen.
- **The doctor CLI silently did nothing when its path contained a symlink**
  (for example macOS `/tmp` → `/private/tmp`). The entry-point check now
  compares real paths.
- **`js-yaml` was only a peer dependency**, so running the doctor from a
  plugin-only profile failed with `ERR_MODULE_NOT_FOUND`. It is now also a
  bundle dependency, and a missing parser degrades to an explicit
  `not-evaluated` YAML check instead of crashing.
- **In-session host detection could pick an unrelated global `dsh`** from
  `PATH`. The running process entry now wins, and conflicting host versions are
  recorded as evidence.
- **Migrated legacy durable pointers were misreported as stale.** A pointer
  that the migration manifest explicitly keeps inactive
  (`No legacy promoted code execution`) is now reported as intentionally
  unmounted.

### Notes

- `scripts/import-evolution-data.mjs` is unchanged: staged, SHA256-verified,
  atomic, idempotent imports that refuse to merge differing source content.
- Known non-blocking limits are reported by every diagnostics run
  (`degradedCapabilities`): advisory domain evaluator, `continuous/` and
  `governance/` not wired into the live loop, host-only promotion through a
  cooperative (non-sandbox) gate, disabled legacy adapters, and the internal
  Cordis surfaces listed in `COMPATIBILITY.md`.
